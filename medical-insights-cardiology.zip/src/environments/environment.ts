export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyAgyD2TweibsZLsWHwNOEyLhc_b_QquHeg",
    authDomain: "cardiology-1d5cb.firebaseapp.com",
    projectId: "cardiology-1d5cb",
    storageBucket: "cardiology-1d5cb.appspot.com",
    messagingSenderId: "358537173747",
    appId: "1:358537173747:web:918f1027df57692e87b586",
    measurementId: "G-P3KD6WVFMZ"
  }
};
