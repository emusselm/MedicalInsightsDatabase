import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../shared/services/auth.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
})

export class DashboardComponent implements OnInit {

  profile = true;
  table = false;

  constructor(public authService: AuthService) {}

  ngOnInit(): void {}

  viewProfile() {
    this.profile = true;
  }

  viewTable() {
    this.profile = false;
    this.table = true;
  }
}
