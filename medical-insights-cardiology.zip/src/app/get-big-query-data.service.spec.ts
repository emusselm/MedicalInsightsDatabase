import { TestBed } from '@angular/core/testing';

import { GetBigQueryDataService } from './get-big-query-data.service';

describe('GetBigQueryDataService', () => {
  let service: GetBigQueryDataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GetBigQueryDataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
